package in.ineuron.service;

public interface IAdminService {

	public boolean getLoginValidation(String email, String password);

}
